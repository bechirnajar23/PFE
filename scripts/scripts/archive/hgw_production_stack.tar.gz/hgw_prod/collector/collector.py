"""
HGW Telemetry Collector — Production
======================================
Connects to a Livebox/HGW via Telnet (using telnet_client.py),
runs system commands, parses output, computes local status,
and inserts into TimescaleDB.

Intended to run as a systemd service or cron job (every 30s-60s).

Usage:
    python collector.py                           # one-shot snapshot
    python collector.py --loop --interval 30      # continuous, every 30s
    python collector.py --dry-run                 # print, don't write to DB
    python collector.py --gateway-id HGW_BUREAU   # override default ID
"""

import argparse
import json
import logging
import os
import re
import signal
import sys
import time
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from pathlib import Path

# Local imports
sys.path.insert(0, str(Path(__file__).parent))
from telnet_client import create_telnet_client, send_command, close_telnet

# DB driver
try:
    import psycopg2
    import psycopg2.extras
    HAS_PG = True
except ImportError:
    HAS_PG = False


logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
)
log = logging.getLogger("collector")


# =============================================================
# COMMAND DEFINITIONS
# =============================================================
# These are the commands the collector runs on the HGW.
# Adjust to match your actual Livebox CLI.
COMMANDS = {
    "uptime":      "uptime",
    "meminfo":     "cat /proc/meminfo",
    "loadavg":     "cat /proc/loadavg",
    "stat":        "cat /proc/stat",
    "ps":          "ps -eo pid,comm,rss --sort=-rss | head -20",
    "wan_state":   "/sbin/ip link show ppp0 2>/dev/null || /sbin/ip link show eth1.835",
    "ping":        "ping -c 4 -W 2 8.8.8.8",
    "dhcp_status": "ps aux | grep -E 'dhclient|udhcpc' | grep -v grep",
}

# CPU/RAM thresholds for local_status computation
CPU_WARN_THRESHOLD = 70
CPU_CRIT_THRESHOLD = 88
MEM_WARN_THRESHOLD = 80
MEM_CRIT_THRESHOLD = 90
LATENCY_WARN_MS    = 120


# =============================================================
# PARSERS
# =============================================================
@dataclass
class Snapshot:
    timestamp: str
    gateway_id: str
    firmware: str = "unknown"
    cpu_load: float = 0.0
    cpu_user_pct: float = 0.0
    cpu_system_pct: float = 0.0
    cpu_idle_pct: float = 100.0
    mem_total_mb: int = 0
    mem_used_mb: int = 0
    mem_free_mb: int = 0
    mem_used_pct: float = 0.0
    buffers_mb: int = 0
    cached_mb: int = 0
    cwmp_rss_mb: float = 0.0
    dhcp_rss_mb: float = 0.0
    nemo_rss_mb: float = 0.0
    ping_latency: float = 0.0
    packet_loss: float = 0.0
    wan_status: int = 1
    wan_rx_kbps: float = 0.0
    wan_tx_kbps: float = 0.0
    dhcp_process_status: str = "UNKNOWN"
    dhcp_data_state: str = "UNKNOWN"
    wan_state: str = "UNKNOWN"
    local_status: str = "NORMAL"
    status_reason: str = "healthy"


def parse_meminfo(text: str) -> dict:
    """Parse /proc/meminfo output (KB → MB)."""
    out = {"total": 0, "free": 0, "available": 0, "buffers": 0, "cached": 0}
    for line in text.splitlines():
        m = re.match(r"^(\w+):\s+(\d+)\s*kB", line)
        if not m:
            continue
        key, val = m.group(1), int(m.group(2)) // 1024  # kB → MB
        if key == "MemTotal":     out["total"] = val
        elif key == "MemFree":    out["free"] = val
        elif key == "MemAvailable": out["available"] = val
        elif key == "Buffers":    out["buffers"] = val
        elif key == "Cached":     out["cached"] = val
    return out


def parse_loadavg(text: str) -> float:
    """Parse /proc/loadavg → return 1-min load × 100 / n_cores."""
    m = re.match(r"^([\d\.]+)\s+([\d\.]+)\s+([\d\.]+)", text.strip())
    if not m:
        return 0.0
    return float(m.group(1))


def parse_stat_cpu_pcts(text: str) -> dict:
    """Parse first 'cpu' line of /proc/stat → user/system/idle percentages."""
    for line in text.splitlines():
        if line.startswith("cpu "):
            parts = line.split()
            if len(parts) < 5:
                return {"user": 0, "system": 0, "idle": 100}
            user, nice, system, idle = (int(x) for x in parts[1:5])
            total = user + nice + system + idle
            if total == 0:
                return {"user": 0, "system": 0, "idle": 100}
            return {
                "user":   round((user + nice) * 100 / total, 1),
                "system": round(system * 100 / total, 1),
                "idle":   round(idle * 100 / total, 1),
            }
    return {"user": 0, "system": 0, "idle": 100}


def parse_ps_processes(text: str) -> dict:
    """Extract RSS in MB for cwmp, dhcp, nemo."""
    out = {"cwmp": 0.0, "dhcp": 0.0, "nemo": 0.0}
    for line in text.splitlines():
        parts = line.split(None, 2)
        if len(parts) < 3:
            continue
        try:
            rss_kb = int(parts[2]) if parts[2].isdigit() else 0
        except (ValueError, IndexError):
            continue
        comm = parts[1].lower() if len(parts) > 1 else ""
        rss_mb = rss_kb / 1024.0
        if "cwmp" in comm:
            out["cwmp"] = max(out["cwmp"], rss_mb)
        elif "dhcp" in comm or "udhcpc" in comm:
            out["dhcp"] = max(out["dhcp"], rss_mb)
        elif "nemo" in comm:
            out["nemo"] = max(out["nemo"], rss_mb)
    return out


def parse_ping(text: str) -> dict:
    """Parse 'ping -c 4' output → avg latency + loss%."""
    out = {"latency": 999.0, "loss": 100.0}
    m_loss = re.search(r"(\d+)%\s+packet\s+loss", text)
    if m_loss:
        out["loss"] = float(m_loss.group(1))
    m_lat = re.search(r"min/avg/max[^=]*=\s*[\d\.]+/([\d\.]+)/", text)
    if m_lat:
        out["latency"] = float(m_lat.group(1))
    return out


def parse_wan_state(text: str) -> dict:
    """Parse 'ip link show' → wan_status (1=UP, 0=DOWN)."""
    if "state UP" in text or "UP," in text:
        return {"status": 1, "state": "UP"}
    elif "state DOWN" in text or "DOWN," in text:
        return {"status": 0, "state": "DOWN"}
    return {"status": 1, "state": "UNKNOWN"}


def parse_dhcp_status(text: str) -> dict:
    """Detect if DHCP client process is running."""
    if "dhclient" in text or "udhcpc" in text:
        return {"process": "RUNNING", "data": "Bound"}
    return {"process": "STOPPED", "data": "UNKNOWN"}


# =============================================================
# STATUS COMPUTATION (matches business rules from datagen.py)
# =============================================================
def compute_local_status(snap: Snapshot) -> tuple:
    """Return (local_status, status_reason) per existing business rules."""
    if snap.dhcp_process_status == "STOPPED":
        return "URGENT", "dhcp_process_stopped"

    local_status = "NORMAL"
    status_reason = "healthy"

    if snap.wan_state != "UP" and snap.wan_state != "UNKNOWN":
        local_status = "WARNING"
        status_reason = "wan_not_up"

    if snap.dhcp_data_state != "Bound" and snap.wan_state == "UP":
        local_status = "WARNING"
        status_reason = "dhcp_not_bound"

    if snap.cpu_load >= CPU_CRIT_THRESHOLD:
        return "URGENT", "high_cpu"
    if snap.cpu_load >= CPU_WARN_THRESHOLD and local_status == "NORMAL":
        local_status = "WARNING"
        status_reason = "cpu_elevated"

    if snap.mem_used_pct >= MEM_CRIT_THRESHOLD:
        return "URGENT", "high_memory"
    if snap.mem_used_pct >= MEM_WARN_THRESHOLD and local_status == "NORMAL":
        local_status = "WARNING"
        status_reason = "memory_elevated"

    if snap.packet_loss > 50 and snap.wan_state == "UP":
        local_status = "WARNING"
        status_reason = "ping_failed"

    if snap.ping_latency >= LATENCY_WARN_MS and local_status == "NORMAL":
        local_status = "WARNING"
        status_reason = "latency_elevated"

    return local_status, status_reason


# =============================================================
# DATA COLLECTION
# =============================================================
def collect_snapshot(gateway_id: str, firmware: str = "unknown") -> Snapshot:
    """Run all commands via telnet, parse, return a Snapshot."""
    snap = Snapshot(
        timestamp=datetime.now(timezone.utc).isoformat(),
        gateway_id=gateway_id,
        firmware=firmware,
    )

    tn = create_telnet_client()
    if tn is None:
        snap.local_status = "URGENT"
        snap.status_reason = "telnet_connection_failed"
        return snap

    try:
        # Memory
        mem_text = send_command(tn, COMMANDS["meminfo"])
        mem = parse_meminfo(mem_text)
        snap.mem_total_mb = mem["total"]
        snap.mem_free_mb  = mem["free"]
        snap.mem_used_mb  = mem["total"] - mem["available"] if mem["available"] else mem["total"] - mem["free"]
        snap.mem_used_pct = round(snap.mem_used_mb * 100 / max(1, snap.mem_total_mb), 2)
        snap.buffers_mb   = mem["buffers"]
        snap.cached_mb    = mem["cached"]

        # CPU
        cpu_text = send_command(tn, COMMANDS["stat"])
        cpu = parse_stat_cpu_pcts(cpu_text)
        snap.cpu_user_pct   = cpu["user"]
        snap.cpu_system_pct = cpu["system"]
        snap.cpu_idle_pct   = cpu["idle"]
        snap.cpu_load       = round(100 - cpu["idle"], 1)

        # Process RSS
        ps_text = send_command(tn, COMMANDS["ps"])
        proc = parse_ps_processes(ps_text)
        snap.cwmp_rss_mb = round(proc["cwmp"], 2)
        snap.dhcp_rss_mb = round(proc["dhcp"], 2)
        snap.nemo_rss_mb = round(proc["nemo"], 2)

        # WAN state
        wan_text = send_command(tn, COMMANDS["wan_state"])
        wan = parse_wan_state(wan_text)
        snap.wan_status = wan["status"]
        snap.wan_state  = wan["state"]

        # Ping
        ping_text = send_command(tn, COMMANDS["ping"], timeout=8)
        ping = parse_ping(ping_text)
        snap.ping_latency = round(ping["latency"], 1)
        snap.packet_loss  = round(ping["loss"], 2)

        # DHCP
        dhcp_text = send_command(tn, COMMANDS["dhcp_status"])
        dhcp = parse_dhcp_status(dhcp_text)
        snap.dhcp_process_status = dhcp["process"]
        snap.dhcp_data_state     = dhcp["data"]

    finally:
        close_telnet(tn)

    # Compute status
    snap.local_status, snap.status_reason = compute_local_status(snap)
    return snap


# =============================================================
# DB INSERTION
# =============================================================
def get_db_conn(dsn: str):
    if not HAS_PG:
        log.error("psycopg2 not installed: pip install psycopg2-binary")
        return None
    try:
        return psycopg2.connect(dsn)
    except Exception as e:
        log.error(f"DB connection failed: {e}")
        return None


def insert_snapshot(conn, snap: Snapshot):
    """Insert snapshot into hgw_telemetry via the helper SQL function."""
    payload = asdict(snap)
    # JSONB column gets the raw payload too
    with conn.cursor() as cur:
        cur.execute(
            "SELECT insert_telemetry(%s::jsonb)",
            (json.dumps(payload),)
        )
    conn.commit()


# =============================================================
# MAIN LOOP
# =============================================================
RUNNING = True

def handle_sigterm(signum, frame):
    global RUNNING
    log.info("Received SIGTERM, stopping after current cycle...")
    RUNNING = False


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--gateway-id", default=os.getenv("GATEWAY_ID", "HGW_001"))
    parser.add_argument("--firmware",   default=os.getenv("FIRMWARE", "unknown"))
    parser.add_argument("--db-dsn",
                          default=os.getenv("DB_DSN",
                              "postgresql://hgw_admin:changeme@localhost:5432/hgw"))
    parser.add_argument("--loop",       action="store_true",
                          help="Run continuously (default: one-shot)")
    parser.add_argument("--interval",   type=int, default=30,
                          help="Seconds between snapshots in loop mode (default 30)")
    parser.add_argument("--dry-run",    action="store_true",
                          help="Print snapshot, do not write to DB")
    parser.add_argument("--max-iterations", type=int, default=0,
                          help="Stop after N iterations (0 = unlimited)")
    args = parser.parse_args()

    signal.signal(signal.SIGTERM, handle_sigterm)
    signal.signal(signal.SIGINT,  handle_sigterm)

    conn = None
    if not args.dry_run:
        conn = get_db_conn(args.db_dsn)
        if conn is None:
            log.error("Cannot run without DB. Use --dry-run to test parsing only.")
            sys.exit(1)
        log.info(f"Connected to DB: {args.db_dsn.split('@')[-1]}")

    iteration = 0
    try:
        while RUNNING:
            iteration += 1
            t0 = time.time()
            try:
                snap = collect_snapshot(args.gateway_id, args.firmware)
                log.info(
                    f"#{iteration}  [{snap.local_status}/{snap.status_reason}]  "
                    f"cpu={snap.cpu_load:.1f}%  mem={snap.mem_used_pct:.1f}%  "
                    f"ping={snap.ping_latency:.0f}ms  "
                    f"cwmp={snap.cwmp_rss_mb:.1f}MB  "
                    f"wan={'UP' if snap.wan_status else 'DOWN'}"
                )
                if args.dry_run:
                    print(json.dumps(asdict(snap), indent=2))
                else:
                    insert_snapshot(conn, snap)
            except Exception as e:
                log.exception(f"Snapshot #{iteration} failed: {e}")

            if not args.loop:
                break
            if args.max_iterations and iteration >= args.max_iterations:
                break

            elapsed = time.time() - t0
            sleep_for = max(1, args.interval - elapsed)
            time.sleep(sleep_for)
    finally:
        if conn is not None:
            conn.close()
        log.info(f"Stopped after {iteration} iteration(s)")


if __name__ == "__main__":
    main()
