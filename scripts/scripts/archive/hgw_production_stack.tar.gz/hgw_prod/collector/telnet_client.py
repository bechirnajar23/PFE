# telnet_client.py (your existing module — ships with collector)
import time

# Compatibilité Python 3.13+ (telnetlib supprimé)
try:
    import telnetlib
    TELNET_LIB = "telnetlib"
    print("[INFO] Utilisation de telnetlib (natif)")
except ImportError:
    import telnetlib3 as telnetlib
    TELNET_LIB = "telnetlib3"
    print("[INFO] Utilisation de telnetlib3")

from config import hostname, port, username, password


def create_telnet_client():
    """Crée et retourne une connexion Telnet à la Livebox"""
    try:
        print(f"[INFO] Connexion Telnet à {hostname}:{port}...")
        tn = telnetlib.Telnet(hostname, port, timeout=10)

        # Attendre le prompt login
        response = tn.read_until(b"login:", timeout=5)
        print(f"[DEBUG] {response.decode('utf-8', errors='ignore').strip()}")

        # Envoyer le nom d'utilisateur
        tn.write(username.encode('utf-8') + b"\n")
        time.sleep(0.5)

        # Attendre le prompt password
        response = tn.read_until(b"Password:", timeout=5)
        print(f"[DEBUG] {response.decode('utf-8', errors='ignore').strip()}")

        # Envoyer le mot de passe
        tn.write(password.encode('utf-8') + b"\n")
        time.sleep(1)

        # Lire jusqu'au prompt #
        response = tn.read_until(b"#", timeout=5)
        print(f"[INFO] Connecté ✅")

        return tn

    except Exception as e:
        print(f"[ERROR] Connexion Telnet échouée : {e}")
        return None


def send_command(tn, command, timeout=5):
    """Envoie une commande et retourne la réponse nettoyée"""
    try:
        # Vider le buffer
        tn.read_very_eager()

        # Envoyer la commande
        tn.write(command.encode('utf-8') + b"\n")
        time.sleep(0.5)

        # Lire jusqu'au prompt #
        response = tn.read_until(b"#", timeout=timeout)
        output = response.decode('utf-8', errors='ignore')

        # Nettoyer la sortie
        clean_lines = []
        for line in output.splitlines():
            line = line.strip()
            if line and line != command and not line.endswith('#'):
                clean_lines.append(line)

        return "\n".join(clean_lines)

    except Exception as e:
        print(f"[ERROR] Commande '{command}' : {e}")
        return ""


def close_telnet(tn):
    """Ferme proprement la connexion Telnet"""
    try:
        if tn:
            tn.write(b"exit\n")
            tn.close()
            print("[INFO] Connexion Telnet fermée")
    except Exception as e:
        print(f"[ERROR] Fermeture Telnet : {e}")
